package Iteratie14.Model;

public class ParchisException extends RuntimeException {

    public ParchisException(String message) {
        super(message);
    }

}
