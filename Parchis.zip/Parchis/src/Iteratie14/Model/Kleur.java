package Iteratie14.Model;

public enum Kleur {
    GEEL,GROEN,BLAUW,ROOD,BLANCO
}
