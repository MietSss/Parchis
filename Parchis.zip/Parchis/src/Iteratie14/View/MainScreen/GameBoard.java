package Iteratie14.View.MainScreen;


import Iteratie14.Model.*;
import Iteratie14.View.UISettings;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;


import java.net.MalformedURLException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class GameBoard extends GridPane {


    private final int vakBreedte;
    private final int vakHoogte;
    private Rectangle vak;
    private Circle nestGroen;
    private Circle nestRood;
    private Circle nestBlauw;
    private Circle nestGeel;
    private Circle safePoint;
    private static final int CANVAS_HOOGTE = 755;
    private static final int CANVAS_BREEDTE = 755;
    private static final Color rood = Color.rgb(250, 0, 0, 0.3);
    private static final Color blauw = Color.rgb(0, 0, 180, 0.3);
    private static final Color groen = Color.rgb(0, 100, 0, 0.3);
    private static final Color geel = Color.rgb(250, 180, 0, 0.3);
    private ImageView pionRood;
    private ImageView pionGeel;
    private ImageView pionGroen;
    private ImageView pionBlauw;
    private Speelbord speelbord;
    private Label naamSpeler;
    private Map<Kleur,Label> labelsNaamSpeler;
    private UISettings uiSettings;
    private List<Kleur> kleurenSpelers;
    private List<String> namenSpelers;
    private List<Node> pionnenGroen;
    private List<Node> pionnenGeel;
    private List<Node> pionnenBlauw;
    private List<Node> pionnenRood;
    private Label  gegooideWaardeSpelerBl;
    private Label gegooideWaardeSpelerGe;
    private Label  gegooideWaardeSpelerRo;
    private Label gegooideWaardeSpelerGr;
    private Label nummerPion;




    public GameBoard(UISettings uiSettings, ParchisModel model) {
        this.speelbord = model.getSpeelbord();
        this.vakBreedte = CANVAS_BREEDTE / Speelbord.AANTAL_KOLOMMEN;
        this.vakHoogte = CANVAS_HOOGTE / Speelbord.AANTAL_RIJEN;
        this.uiSettings = uiSettings;
        pionnenBlauw=new ArrayList<>();
        pionnenGeel=new ArrayList<>();
        pionnenRood=new ArrayList<>();
        pionnenGroen=new ArrayList<>();
        labelsNaamSpeler=new LinkedHashMap<>();
        gegooideWaardeSpelerBl=new Label();
        gegooideWaardeSpelerRo=new Label();
        gegooideWaardeSpelerGe=new Label();
        gegooideWaardeSpelerGr=new Label();

        //te deleten:
        try {
            kleurenSpelers = model.getSpelers().getKleurenSpelers();
            namenSpelers = model.getSpelers().getNamenSpelers();
        } catch (ParchisException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error attributen spelers");
            alert.setContentText("Er zijn geen namen of kleuren van spelers beschikbaar");
            alert.showAndWait();
        }

        this.initialiseNodes();
        this.layoutNodes();
    }


    private void initialiseNodes() {
        nestBlauw = new Circle((vakBreedte * 6) * 0.5, Color.TRANSPARENT);
        nestGroen = new Circle((vakBreedte * 6) * 0.5, Color.TRANSPARENT);
        nestGeel = new Circle((vakBreedte * 6) * 0.5, Color.TRANSPARENT);
        nestRood = new Circle((vakBreedte * 6) * 0.5, Color.TRANSPARENT);

        //teken speelbord
        for (int x = 0; x < Speelbord.AANTAL_KOLOMMEN; x++) {
            for (int y = 0; y < Speelbord.AANTAL_RIJEN; y++) {
                for (Vak vak1 : speelbord.getVakken()) {
                    if (vak1.getX() == x && vak1.getY() == y) {
                        int vakNummer = vak1.getVakNummer();
                        Text vakNummerText = new Text("");
                        if (vakNummer < 69) {
                            vakNummerText = new Text(Integer.toString(vakNummer));
                        }

                        vakNummerText.setFont(Font.font("Bradley Hand ITC"));
                        vak = new Rectangle(x, y, vakBreedte, vakHoogte);
                        vak.setStroke(Color.BLACK);
                        Kleur kleur = vak1.getKleur();
                        switch (kleur) {
                            case BLAUW:
                                vak.setFill(blauw);
                                break;
                            case GEEL:
                                vak.setFill(geel);
                                break;
                            case ROOD:
                                vak.setFill(rood);
                                break;
                            case GROEN:
                                vak.setFill(groen);
                                break;
                            case BLANCO:
                                vak.setFill(Color.TRANSPARENT);
                        }
                        vakNummerText.setTextAlignment(TextAlignment.CENTER);
                        HBox hbox = new HBox();
                        this.add(vak, x, y);
                        this.add(vakNummerText, x, y);

                        this.add(hbox, x, y);
                        if (vak1.isSafePoint()) {
                            safePoint = new Circle(x, y, vakBreedte * 0.5, Color.TRANSPARENT);
                            safePoint.setStroke(Color.BLACK);
                            this.add(safePoint, x, y);

                        }
                    }
                }
            }
        }
        //te wijzigen met parameter Spelers
        plaatsPionnen(kleurenSpelers);
        //voeg namen toe van de spelers obv kleur
        if(kleurenSpelers.size()!=0) {
            plaatsNamenSpelers(kleurenSpelers, namenSpelers);
        }

        this.setPrefSize(755, 755);

    }

    private void layoutNodes() {

        nestGroen.setStroke(groen);
        nestGroen.setStrokeWidth(10);
        nestBlauw.setStroke(blauw);
        nestBlauw.setStrokeWidth(10);
        nestGeel.setStroke(geel);
        nestGeel.setStrokeWidth(10);
        nestRood.setStroke(rood);
        nestRood.setStrokeWidth(10);
        //set column & row constraints:
        for (int i = 0; i < Speelbord.AANTAL_KOLOMMEN; i++) {

            ColumnConstraints column = new ColumnConstraints();
            column.setPercentWidth(50);
            this.getColumnConstraints().add(column);
      //      column.setHgrow(Priority.ALWAYS);
        }

        for (int j = 0; j < Speelbord.AANTAL_RIJEN; j++) {
            RowConstraints row = new RowConstraints();
            row.setPercentHeight(50);
      //      row.setVgrow(Priority.ALWAYS);
            this.getRowConstraints().add(row);
        }
        //plaats nodes op pane:
        this.setPrefSize(CANVAS_BREEDTE, CANVAS_HOOGTE);
        this.add(nestBlauw, 1, 0, 6, 8);
        this.add(nestGeel, 14, 0, 19, 8);
        this.add(nestRood, 1, 13, 6, 19);
        this.add(nestGroen, 14, 13, 19, 19);
        this.setPadding(new Insets(10));

        this.setGridLinesVisible(true);


// Layout van de Nodes
// add… methodes (of set…)
// Insets, padding, alignment, …

    }


    public Circle getSafePoint() {
        return safePoint;
    }


    public static Color getRood() {
        return rood;
    }

    public static Color getBlauw() {
        return blauw;
    }

    public static Color getGroen() {
        return groen;
    }

    public static Color getGeel() {
        return geel;
    }



    public Speelbord getSpeelbord() {
        return speelbord;
    }

    public Label getNaamSpeler() {
        return naamSpeler;
    }

    public UISettings getUiSettings() {
        return uiSettings;
    }

    private Node getHBox(int x, int y) {
        ObservableList<Node> childrens = this.getChildren();

        for (Node node : childrens) {
            if (node instanceof HBox) {
                if (this.getRowIndex(node) == y && this.getColumnIndex(node) == x) {
                    return node;
                }
            }

        }
        return null;
    }



    public List<Node> getPionnenGroen() {
        return pionnenGroen;
    }

    public List<Node> getPionnenGeel() {
        return pionnenGeel;
    }

    public List<Node> getPionnenRood() {
        return pionnenRood;
    }

    public List<Node> getPionnenBlauw() {
        return pionnenBlauw;
    }

    public Label getGegooideWaardeSpelerBl() {
        return gegooideWaardeSpelerBl;
    }

    public Label getGegooideWaardeSpelerGe() {
        return gegooideWaardeSpelerGe;
    }

    public Label getGegooideWaardeSpelerRo() {
        return gegooideWaardeSpelerRo;
    }

    public Label getGegooideWaardeSpelerGr() {
        return gegooideWaardeSpelerGr;
    }

    public Map<Kleur, Label> getLabelsNaamSpeler() {
        return labelsNaamSpeler;
    }

    //plaats de nodige pionnen op bord obv gekozen kleuren van de spelers
    private void plaatsPionnen(List<Kleur> kleurenSpelers) {
        if (kleurenSpelers.size() != 0) {
            for (Kleur kleurSpeler : kleurenSpelers) {
                switch (kleurSpeler) {
                    case ROOD:
                        List<Vak> vakkenNestRood = speelbord.getNest(Kleur.ROOD);
                        if (Files.exists(uiSettings.getPionRoodPah())) {
                            for (int i = 0; i < 4; i++) {
                                try {
                                    pionRood = new ImageView(new Image(uiSettings.getPionRoodPah().toUri().toURL().toString()));
                                    int nummer=i+1;
                                    nummerPion=new Label(String.valueOf(nummer));
                                    pionRood.setFitHeight(vakHoogte / 2);
                                    pionRood.setFitWidth(vakBreedte / 2);
                                    int xr = vakkenNestRood.get(i).getX();
                                    int yr = vakkenNestRood.get(i).getY();
                                    HBox hboxr = (HBox) getHBox(xr, yr);
                                    hboxr.getChildren().addAll(pionRood,nummerPion);
                                    hboxr.setAlignment(Pos.CENTER);
                                    pionnenRood.add(pionRood);
                                } catch (MalformedURLException e) {

                                }
                            }
                        }
                        break;
                    case GROEN:
                        List<Vak> vakkenNestGroen = speelbord.getNest(Kleur.GROEN);
                        if (Files.exists(uiSettings.getPionGroenPath())) {
                            for (int i = 0; i < 4; i++) {
                                try {
                                    pionGroen = new ImageView(new Image(uiSettings.getPionGroenPath().toUri().toURL().toString()));
                                    int nummer=i+1;
                                    nummerPion=new Label(String.valueOf(nummer));
                                    pionGroen.setFitHeight(vakHoogte / 2);
                                    pionGroen.setFitWidth(vakHoogte / 2);
                                    int xgr = vakkenNestGroen.get(i).getX();
                                    int ygr = vakkenNestGroen.get(i).getY();
                                    HBox hboxgr = (HBox) getHBox(xgr, ygr);
                                    hboxgr.getChildren().addAll(pionGroen,nummerPion);
                                    hboxgr.setAlignment(Pos.CENTER);
                                    pionnenGroen.add(pionGroen);
                                } catch (MalformedURLException ex) {

                                }
                            }
                        }
                        break;
                    case GEEL:
                        List<Vak> vakkenNestGeel = speelbord.getNest(Kleur.GEEL);
                        if (Files.exists(uiSettings.getPionGeelPath())) {
                            for (int i = 0; i < 4; i++) {
                                try {
                                    pionGeel = new ImageView(new Image(uiSettings.getPionGeelPath().toUri().toURL().toString()));
                                    int nummer=i+1;
                                    nummerPion=new Label(String.valueOf(nummer));
                                    pionGeel.setFitHeight(vakHoogte / 2);
                                    pionGeel.setFitWidth(vakHoogte / 2);
                                    int xge = vakkenNestGeel.get(i).getX();
                                    int yge = vakkenNestGeel.get(i).getY();
                                    HBox hboxge = (HBox) getHBox(xge, yge);
                                    hboxge.getChildren().addAll(pionGeel,nummerPion);
                                    hboxge.setAlignment(Pos.CENTER);
                                    pionnenGeel.add(pionGeel);
                                } catch (MalformedURLException e) {

                                }
                            }
                        }
                        break;
                    case BLAUW:
                        List<Vak> vakkenNestBlauw = speelbord.getNest(Kleur.BLAUW);
                        if (Files.exists(uiSettings.getPionBlauwPath())) {
                            for (int i = 0; i < 4; i++) {
                                try {
                                    pionBlauw = new ImageView(new Image(uiSettings.getPionBlauwPath().toUri().toURL().toString()));
                                    int nummer=i+1;
                                    nummerPion=new Label(String.valueOf(nummer));
                                    pionBlauw.setFitHeight(vakHoogte / 2);
                                    pionBlauw.setFitWidth(vakHoogte / 2);
                                    int xb = vakkenNestBlauw.get(i).getX();
                                    int yb = vakkenNestBlauw.get(i).getY();
                                    HBox hboxb = (HBox) getHBox(xb, yb);
                                    hboxb.getChildren().addAll(pionBlauw,nummerPion);
                                    hboxb.setAlignment(Pos.CENTER);
                                    pionnenBlauw.add(pionBlauw);
                                } catch (MalformedURLException e) {

                                }
                            }
                        }
                        break;

                }
            }
        }
    }

    private void plaatsNamenSpelers(List<Kleur> kleurenSpelers, List<String> namenSpelers) {
        for (int i = 0; i < namenSpelers.size(); i++) {
            String labeltext = namenSpelers.get(i);
            naamSpeler = new Label(labeltext);
            naamSpeler.setFont(Font.font(16));
          //  naamSpeler.setWrapText(true);
           // naamSpeler.setMaxWidth(vakBreedte * 4);
            naamSpeler.setMaxHeight(vakHoogte);
            naamSpeler.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID,
                    CornerRadii.EMPTY, new BorderWidths(3))));
            Kleur kleurSpeler = kleurenSpelers.get(i);
            switch (kleurSpeler) {
                case BLAUW:
                    this.add(naamSpeler, 3, 5, 9, 5);
                    labelsNaamSpeler.put(Kleur.BLAUW,naamSpeler);
                    this.add(gegooideWaardeSpelerBl,10,5,12,5);
                    break;
                case GEEL:
                    this.add(naamSpeler, 14, 5, 18, 5);
                    labelsNaamSpeler.put(Kleur.GEEL,naamSpeler);
                    this.add(gegooideWaardeSpelerGe,19,5,20,5);
                    break;
                case ROOD:
                    this.add(naamSpeler, 3, 9, 9, 9);
                    labelsNaamSpeler.put(Kleur.ROOD,naamSpeler);
                    this.add(gegooideWaardeSpelerRo,10,9,12,9);
                    break;
                case GROEN:
                    this.add(naamSpeler, 14, 9, 18, 9);
                    labelsNaamSpeler.put(Kleur.GROEN,naamSpeler);
                    this.add(gegooideWaardeSpelerGr,19,9,20,9);
                    break;
            }
        }
    }


// implementatie van de nodige
// package-private Getters
}

