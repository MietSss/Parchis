package Iteratie14.View.MainScreen;

import Iteratie14.Model.*;
import Iteratie14.View.UISettings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.net.MalformedURLException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class MainScreenView extends BorderPane {

    private MenuItem exitMI;
    private MenuItem saveMI;
    private MenuItem loadMI;
    private MenuItem settingsMI;
    private MenuItem aboutMI;
    private MenuItem infoMI;
    private final UISettings uiSettings;
    private final GameBoard gameBoardView;
    private TextArea textInstructies;
    private ImageView dobbelsteen6;
    private ImageView dobbelsteen5;
    private ImageView dobbelsteen4;
    private ImageView dobbelsteen3;
    private ImageView dobbelsteen2;
    private ImageView dobbelsteen1;
    private Label titel;
    private VBox vBox;
    private Button dobbelsteen;
    private List<ImageView> dobbelstenenImages;
   // private Button nextInstruction;

    public MainScreenView(UISettings uiSettings, ParchisModel model) {
        this.uiSettings = uiSettings;
        gameBoardView = new GameBoard(uiSettings, model);
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        this.exitMI = new MenuItem("Exit");
        this.saveMI = new MenuItem("Save");
        this.loadMI = new MenuItem("Load");
        this.settingsMI = new MenuItem("Settings");
        this.aboutMI = new MenuItem("About");
        this.infoMI = new MenuItem("Info");
        textInstructies = new TextArea();
        dobbelstenenImages=new ArrayList<>();


        titel = new Label("Instructies:");
        if (Files.exists(uiSettings.getDobbelsteen6())) {
            try {
                dobbelsteen6 = new ImageView(new Image(uiSettings.getDobbelsteen6().toUri().toURL().toString()));
                dobbelsteen6.setFitHeight(100);
                dobbelsteen6.setFitWidth(100);
                dobbelstenenImages.add(dobbelsteen6);
                dobbelsteen = new Button("", dobbelsteen6);

            } catch (MalformedURLException e) {

            }
            if (Files.exists(uiSettings.getDobbelsteen5())) {
                try {
                    dobbelsteen5 = new ImageView(new Image(uiSettings.getDobbelsteen5().toUri().toURL().toString()));
                    dobbelsteen5.setFitHeight(100);
                    dobbelsteen5.setFitWidth(100);

                } catch (MalformedURLException e) {

                }
            }
            if (Files.exists(uiSettings.getDobbelsteen4())) {
                try {
                    dobbelsteen4 = new ImageView(new Image(uiSettings.getDobbelsteen4().toUri().toURL().toString()));
                    dobbelsteen4.setFitHeight(100);
                    dobbelsteen4.setFitWidth(100);

                } catch (MalformedURLException e) {

                }
            }
            if (Files.exists(uiSettings.getDobbelsteen3())) {
                try {
                    dobbelsteen3 = new ImageView(new Image(uiSettings.getDobbelsteen3().toUri().toURL().toString()));
                    dobbelsteen3.setFitHeight(100);
                    dobbelsteen3.setFitWidth(100);

                } catch (MalformedURLException e) {

                }
            }
            if (Files.exists(uiSettings.getDobbelsteen2())) {
                try {
                    dobbelsteen2 = new ImageView(new Image(uiSettings.getDobbelsteen2().toUri().toURL().toString()));
                    dobbelsteen2.setFitHeight(100);
                    dobbelsteen2.setFitWidth(100);

                } catch (MalformedURLException e) {

                }
            }
            if (Files.exists(uiSettings.getDobbelsteen1())) {
                try {
                    dobbelsteen1 = new ImageView(new Image(uiSettings.getDobbelsteen1().toUri().toURL().toString()));
                    dobbelsteen1.setFitHeight(100);
                    dobbelsteen1.setFitWidth(100);

                } catch (MalformedURLException e) {

                }
            }
        }
        vBox = new VBox();

    }

    private void layoutNodes() {
        Menu menuFile = new Menu("File", null, loadMI, saveMI, new SeparatorMenuItem(), settingsMI, new SeparatorMenuItem(), exitMI);
        Menu menuHelp = new Menu("Help", null, aboutMI, infoMI);
        MenuBar menuBar = new MenuBar(menuFile, menuHelp);
        setTop(menuBar);
        titel.setFont(Font.font(50));
        textInstructies.setFont(Font.font("Verdana", FontWeight.BOLD, 15));
        // textInstructies.setMaxWidth(Double.MAX_VALUE);
        textInstructies.setMaxHeight(Double.MAX_VALUE);
        textInstructies.setMaxWidth(200);
        textInstructies.setEditable(false);
        textInstructies.setWrapText(true);
        VBox.setVgrow(textInstructies, Priority.ALWAYS);
        dobbelsteen.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        VBox.setVgrow(dobbelsteen, Priority.ALWAYS);
        vBox.setSpacing(20);
        vBox.setPadding(new Insets(10));
        // vBox.setMaxWidth(GridPane.getRowSpan(vBox));
        vBox.getChildren().addAll(titel, textInstructies, dobbelsteen);
        vBox.setAlignment(Pos.CENTER);
        //VBox.setMargin(textInstructies, new Insets(10,10,10,10));
        //VBox.setMargin(dobbelsteen, new Insets(10,10,10,10));
        BorderPane.setMargin(vBox, new Insets(10, 10, 10, 10));
        this.setLeft(gameBoardView);
        this.setRight(vBox);
        //  this.setPadding(new Insets(10));

    }

    MenuItem getExitItem() {
        return exitMI;
    }

    MenuItem getSaveItem() {
        return saveMI;
    }

    MenuItem getLoadItem() {
        return loadMI;
    }

    MenuItem getSettingsItem() {
        return settingsMI;
    }

    MenuItem getAboutItem() {
        return aboutMI;
    }

    MenuItem getInfoItem() {
        return infoMI;
    }

    public GameBoard getGameBoardView() {
        return gameBoardView;
    }

    public TextArea getTextInstructies() {
        return textInstructies;
    }

    public Button getDobbelsteen() {
        return dobbelsteen;
    }

    public ImageView getDobbelsteen6() {
        return dobbelsteen6;
    }

    public ImageView getDobbelsteen5() {
        return dobbelsteen5;
    }

    public ImageView getDobbelsteen4() {
        return dobbelsteen4;
    }

    public ImageView getDobbelsteen3() {
        return dobbelsteen3;
    }

    public ImageView getDobbelsteen2() {
        return dobbelsteen2;
    }

    public ImageView getDobbelsteen1() {
        return dobbelsteen1;
    }
}
