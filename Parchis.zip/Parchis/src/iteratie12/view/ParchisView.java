package iteratie12.view;

import javafx.scene.layout.BorderPane;

public class ParchisView extends BorderPane
        /* layout type */ {
    // private Node attributen (controls)
    public ParchisView() {
        this.initialiseNodes();
        this.layoutNodes();
    }
    private void initialiseNodes() {
// Initialisatie van de Nodes
// bvb.:
// button = new Button("...")
// label = new Label("...")
    }
    private void layoutNodes() {
// Layout van de Nodes
// add… methodes (of set…)
// Insets, padding, alignment, …
    }
// implementatie van de nodige
// package-private Getters
}

