package iteratie12.model;


public class TestParchis {
    public static void main(String[] args) {
    Parchis parchis = new Parchis();
    parchis.start();

    }
}


