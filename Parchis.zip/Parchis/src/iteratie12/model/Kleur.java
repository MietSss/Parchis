package iteratie12.model;

public enum Kleur {
    GEEL,GROEN,BLAUW,ROOD,BLANCO;
}
