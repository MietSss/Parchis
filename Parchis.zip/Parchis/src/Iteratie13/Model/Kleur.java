package Iteratie13.Model;

public enum Kleur {
    GEEL,GROEN,BLAUW,ROOD,BLANCO
}
